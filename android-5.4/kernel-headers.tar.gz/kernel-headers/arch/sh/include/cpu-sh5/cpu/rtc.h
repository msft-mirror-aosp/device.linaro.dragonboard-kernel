/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_SH_CPU_SH5_RTC_H
#define __ASM_SH_CPU_SH5_RTC_H

#define rtc_reg_size		sizeof(u32)
#define RTC_BIT_INVERTED	0	/* The SH-5 RTC is surprisingly sane! */
#define RTC_DEF_CAPABILITIES	RTC_CAP_4_DIGIT_YEAR

#endif /* __ASM_SH_CPU_SH5_RTC_H */
