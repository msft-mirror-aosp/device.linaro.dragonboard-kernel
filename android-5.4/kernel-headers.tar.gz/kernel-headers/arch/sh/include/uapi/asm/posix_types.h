/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __KERNEL__
# ifdef __SH5__
#  include <asm/posix_types_64.h>
# else
#  include <asm/posix_types_32.h>
# endif
#endif /* __KERNEL__ */
