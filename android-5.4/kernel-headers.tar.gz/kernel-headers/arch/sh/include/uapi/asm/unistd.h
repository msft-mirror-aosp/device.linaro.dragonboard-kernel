/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __KERNEL__
# ifdef __SH5__
#  include <asm/unistd_64.h>
# else
#  include <asm/unistd_32.h>
# endif
#endif
