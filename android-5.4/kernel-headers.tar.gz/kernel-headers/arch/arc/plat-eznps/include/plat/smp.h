/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright(c) 2015 EZchip Technologies.
 */

#ifndef __PLAT_EZNPS_SMP_H
#define __PLAT_EZNPS_SMP_H

#ifdef CONFIG_SMP

extern void res_service(void);

#endif /* CONFIG_SMP */

#endif
