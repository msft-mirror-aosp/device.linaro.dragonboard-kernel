/* SPDX-License-Identifier: GPL-2.0 */
#include <asm/string_32.h>
