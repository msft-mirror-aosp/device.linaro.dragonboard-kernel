/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 * There isn't anything here anymore, but the file must not be empty or patch
 * will delete it.
 */
