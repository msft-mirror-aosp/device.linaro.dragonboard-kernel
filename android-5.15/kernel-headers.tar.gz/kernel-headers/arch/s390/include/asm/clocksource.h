/* SPDX-License-Identifier: GPL-2.0 */
/* s390-specific clocksource additions */

#ifndef _ASM_S390_CLOCKSOURCE_H
#define _ASM_S390_CLOCKSOURCE_H

#endif /* _ASM_S390_CLOCKSOURCE_H */
