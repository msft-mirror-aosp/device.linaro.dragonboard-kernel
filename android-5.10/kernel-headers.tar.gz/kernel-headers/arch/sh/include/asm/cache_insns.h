/* SPDX-License-Identifier: GPL-2.0 */
#include <asm/cache_insns_32.h>
